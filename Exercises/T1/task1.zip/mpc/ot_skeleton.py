#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import sys, os
from struct import pack, unpack

class BetterSocket(object):

    """A wrapper around a socket to easier send/recv stuff safely."""
    def __init__(self, socket):
        self.sock = socket

    def send(self, data):
        totalsent = 0
        while totalsent < len(data):
            sent = self.sock.send(data[totalsent:])
            if sent == 0:
                raise RuntimeError("socket connection broken")
            totalsent = totalsent + sent

    def recv(self, length):
        chunks = []
        bytes_recd = 0
        while bytes_recd < length:
            chunk = self.sock.recv(min(length - bytes_recd, 2048))
            if chunk == '':
                raise RuntimeError("socket connection broken")
            chunks.append(chunk)
            bytes_recd = bytes_recd + len(chunk)
        return b''.join(chunks)

    # Example helper functions, you can add your own
    # send a bit value to the other party, expanded into a full byte
    def send_bit(self, i):
        self.send(i.to_bytes(1, byteorder='big'))

    # receive a bit value from the other party, expanded into a full byte
    def recv_bit(self):
        return int.from_bytes(self.recv(1), byteorder='big')

class Reciever(object):

    """OT Reciever. """

    def __init__(self, ip='localhost', port=7777):
        self.ip = ip
        self.port = port

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.ip, self.port))
        self.conn = BetterSocket(self.sock)

    def disconnect(self):
        self.sock.close()
        self.conn = None

    def recv1of2(self, choice):
        """Implements the 1-out-of-2 OT."""
        if choice not in [0,1]:
            raise ValueError('choice must be 0 or 1')

        if self.conn is None:
            raise RuntimeError('connect the two parties first')

        # BEGIN STUDENT TODO ##################################################
        # example of networking
        # self.conn.send(b'TEST')
        # END STUDENT TODO   ##################################################
        return message

    def recv1ofN(self, N, choice):
        """Implements the 1-out-of-N OT"""
        if choice < 0 or choice >= N:
            raise ValueError('choice must be in [0,N)')

        if self.conn is None:
            raise RuntimeError('connect the two parties first')

        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################

        return message

    def share(self, val):
        """ shares the bit value val with another party.
            returns own share, while sending other share to second party. """
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return my_share

    def recvShare(self):
        """ receive one share of a bit value from another party. """
        my_share = self.conn.recv_bit()
        return my_share

    def reconstruct(self, my_share):
        """ Reconstruct a shared bit value val by communicating shares between parties. """
        self.conn.send_bit(my_share)
        other_share = self.conn.recv_bit()
        return my_share ^ other_share

    def XOR(self, in1_share, in2_share):
        """ Implements an XOR gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share

    def AND(self, in1_share, in2_share):
        """ Implements an AND gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share

    def OR(self, in1_share, in2_share):
        """ Implements an OR gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share


class Sender(object):

    """OT Sender. """

    def __init__(self, port=7777):
        """Constructor for Sender, taking a port on which the sender listens
        for the reciever."""
        self.ssock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.ssock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.ssock.bind(('', port))
        self.ssock.listen(5)

    def connect(self):
        self.sock,_ = self.ssock.accept()
        self.conn = BetterSocket(self.sock)

    def disconnect(self):
        self.sock.close()
        self.conn = None

    def send1of2(self, message0, message1):
        """Implements the 1-out-of-2 OT."""
        try:
            message0 = bytearray(message0)
            message1 = bytearray(message1)
            if not (len(message0) == len(message1)):
                raise ValueError()
        except Exception as e:
            raise ValueError('message1 and message2 need to be bytearrays')

        if self.conn is None:
            raise RuntimeError('connect the two parties first')

        # BEGIN STUDENT TODO ##################################################
        # example networking
        # test = self.conn.recv(4)
        # print(test)
        # END STUDENT TODO   ##################################################

    def send1ofN(self, N, messages):
        """Implements the 1-out-of-N OT."""
        if len(messages) != N:
            raise ValueError('Must give N messages')

        if self.conn is None:
            raise RuntimeError('connect the two parties first')

        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################

    def share(self, val):
        """ shares the bit value val with another party.
            returns own share, while sending other share to second party. """
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return my_share

    def recvShare(self):
        """ receive one share of a bit value from another party. """
        my_share = self.conn.recv_bit()
        return my_share

    def reconstruct(self, my_share):
        """ Reconstruct a shared bit value val by communicating shares between parties. """
        other_share = self.conn.recv_bit()
        self.conn.send_bit(my_share)
        return my_share ^ other_share

    def XOR(self, in1_share, in2_share):
        """ Implements an XOR gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share

    def AND(self, in1_share, in2_share):
        """ Implements an AND gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share

    def OR(self, in1_share, in2_share):
        """ Implements an OR gate for the input shares in1 and in2, shared with another party."""
        # BEGIN STUDENT TODO ##################################################
        # END STUDENT TODO   ##################################################
        return out_share

    def cleanup(self):
        self.ssock.close()

class AdditionCircuit(object):
    """ A 4-bit full adder circuit. Uses the Gate functionality provided by party
        to compute the addition circuit."""

    def __init__(self, party):
        self.party = party

    def fullAdder(self, x, y, c_in):
        "Calculates x+y=z, with carry input c_in and carry output c_out."
        assert x in (0,1) and y in (0,1) and c_in in (0,1)

        t1 = self.party.XOR(x, y)
        z  = self.party.XOR(c_in, t1)

        t2 = self.party.AND(x, y)
        t3 = self.party.AND(c_in, t1)
        c_out = self.party.OR(t2, t3)
        return (z, c_out)

    def fourBitAdder(self, a, b, isAlice):
        assert a is None or 0 <= a < 16
        assert b is None or 0 <= b < 16

        # for either party, split their respective input into bits
        # and share them with the other party
        if isAlice:
            a_0 = (a >> 0) & 1
            a_1 = (a >> 1) & 1
            a_2 = (a >> 2) & 1
            a_3 = (a >> 3) & 1

            a0 = self.party.share(a_0)
            a1 = self.party.share(a_1)
            a2 = self.party.share(a_2)
            a3 = self.party.share(a_3)

            b0 = self.party.recvShare()
            b1 = self.party.recvShare()
            b2 = self.party.recvShare()
            b3 = self.party.recvShare()

            c0 = self.party.share(0)
        else:
            b_0 = (b >> 0) & 1
            b_1 = (b >> 1) & 1
            b_2 = (b >> 2) & 1
            b_3 = (b >> 3) & 1

            a0 = self.party.recvShare()
            a1 = self.party.recvShare()
            a2 = self.party.recvShare()
            a3 = self.party.recvShare()

            b0 = self.party.share(b_0)
            b1 = self.party.share(b_1)
            b2 = self.party.share(b_2)
            b3 = self.party.share(b_3)

            c0 = self.party.recvShare()

        # call 4 seperate full adder circuits
        o0, c1 = self.fullAdder(a0, b0, c0) 
        o1, c2 = self.fullAdder(a1, b1, c1) 
        o2, c3 = self.fullAdder(a2, b2, c2) 
        o3, c4 = self.fullAdder(a3, b3, c3) 

        # recombine the shares of the output bits
        o_0 = self.party.reconstruct(o0)
        o_1 = self.party.reconstruct(o1)
        o_2 = self.party.reconstruct(o2)
        o_3 = self.party.reconstruct(o3)
        o_4 = self.party.reconstruct(c4)

        # reconstruct the 5-bit output
        o = (o_0 << 0) | (o_1 << 1) | (o_2 << 2) | (o_3 << 3) | (o_4 << 4)

        return o


# a simple main function to test the functionality
# call ./ot_skeleton.py 0 in one terminal to start sender,
# then call ./ot_skeleton.py 1 in second terminal to start receiver
if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] not in ['0','1']:
        print('Usage: {} <role>\n\trole: 0 = Sender, 1 = Reciever'.format(sys.argv[0]))
        sys.exit(1)

    N = 2**7
    if sys.argv[1] == '0':
        sender = Sender()
        sender.connect()
        # test 1-out-of-2-OT
        sender.send1of2(b'A'*32, b'B'*32)
        # test 1-out-of-N-OT
        sender.send1ofN(N, [b'0'*28 + pack('>I',i) for i in range(N)])
        # test Addition Circuit
        circ = AdditionCircuit(sender)
        print(circ.fourBitAdder(6, None, True))
        sender.disconnect()
        sender.cleanup()
    else:
        recv = Reciever()
        recv.connect()
        # test 1-out-of-2-OT
        print(recv.recv1of2(1))
        # test 1-out-of-N-OT
        print(recv.recv1ofN(N, 66))
        circ = AdditionCircuit(recv)
        # test Addition Circuit
        print(circ.fourBitAdder(None, 5, False))
        recv.disconnect()
